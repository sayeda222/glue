
<div class="theme-white js-cookie-consent cookie-consent">
    <div class="cookie-popup position-bottom hidden" style="display: block;">
        <div class="cookie-popup-inner">
            <div class="cookie-popup-left">
                <div class="cookie-popup-headline"> We Care about your privacy </div>
                <div class="cookie-popup-sub-headline ">
                    <?php echo trans('cookie-consent::texts.message'); ?>

                </div>
            </div>
            <div class="cookie-popup-right">
                <a href="#" class="cookie-popup-accept-cookies js-cookie-consent-agree cookie-consent__agree cursor-pointer"><?php echo e(trans('langconvert.menu.accept')); ?></a>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/bahonbdc/public_html/ticket/resources/views/vendor/cookie-consent/dialogContents.blade.php ENDPATH**/ ?>